// Run once the document is loaded
document.addEventListener('DOMContentLoaded', function () {
    const currentPage = window.location.pathname;

    // ------------------------------------
    // 1. INDEX PAGE - Optional welcome
    // ------------------------------------
    if (currentPage.includes("index.html")) {
        console.log("Welcome to the Home Page");
        // Optional: Show welcome alert
        // alert("Welcome to Singapore Wildlife Foundation!");
    }

    // ------------------------------------
    // 2. ABOUT PAGE
    // ------------------------------------
    if (currentPage.includes("about.html")) {
        console.log("You are on the About Page");
    }

    // ------------------------------------
    // 3. ANIMALS PAGE - Hover effect on animal images
    // ------------------------------------
    if (currentPage.includes("animal.html")) {
        const animalImages = document.querySelectorAll("figure img");

        animalImages.forEach(img => {
            img.addEventListener("mouseenter", () => {
                img.style.transform = "scale(1.05)";
                img.style.transition = "transform 0.3s ease";
            });

            img.addEventListener("mouseleave", () => {
                img.style.transform = "scale(1)";
            });
        });
    }

    // ------------------------------------
    // 4. FEEDBACK PAGE - Form validation
    // ------------------------------------
    const form = document.getElementById('feedbackForm');
    const feedbackMsg = document.getElementById('feedbackMessage');

    if (form && feedbackMsg) {
        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const rating = document.getElementById('rating').value;
            const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;

            let message = '';
            let isValid = true;

            if (!name || !email || !rating) {
                message = 'Please fill out all required fields.';
                feedbackMsg.style.color = 'red';
                isValid = false;
            } else if (!emailPattern.test(email)) {
                message = 'Please enter a valid email address.';
                feedbackMsg.style.color = 'red';
                isValid = false;
            }

            if (isValid) {
                message = 'Thank you for your feedback!';
                feedbackMsg.style.color = 'green';
                // Optionally: form.reset();
            }

            feedbackMsg.textContent = message;
        });
    }
});
// ...existing code...
window.addEventListener('scroll', function () {
    const btn = document.getElementById('backToTop');
    if (window.scrollY > 200) {
        btn.style.display = 'block';
    } else {
        btn.style.display = 'none';
    }
});

document.getElementById('backToTop').addEventListener('click', function () {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
// ...existing code...
